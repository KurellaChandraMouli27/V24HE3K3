#include "header.h"

extern USER *head;
extern STORE *head1;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void libmenu(void)
{
	int i;
	while(1)
	{
		b:printf(BLUE"\n1.ADD USER / 2.DELETE USER / 3.EDIT USER /  4.ADD BOOK / 5.DELETE BOOK / 6.EDIT BOOK / 7.DISPLAY CURRENT STATUS / 8.EXIT\n"COLROFF);
  		printf("\nEnter the choice:");
  		__fpurge(stdin);
 		 scanf("%d",&i);
  switch(i)
  {
	  case 1:adduser();
		 break;
	  case 2:deluser();
		 break;
	  case 3:edituser();
		 break;
	  case 4:addbook();
		 break;
	  case 5:delbook();
		 break;
	  case 6:editbook();
		 break;
	  case 7:dispstat();
		 break;
	  case 8:saveuser();
		 savebook(head1);
		 return;
	  default :printf(RED"\nInvalid Input\n"COLROFF);
		   break;
  }
  saveuser();
  savebook(head1);

	}
}

