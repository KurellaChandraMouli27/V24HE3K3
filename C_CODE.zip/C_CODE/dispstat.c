#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

char *remv(char *p)
{
	p[strlen(p)-1]='\0';
	return p;
}


void dispstat(void)
{
	char *s;
	int flag=0;
	USER *temp=NULL;
	STORE *temp1=NULL;
	BOOK *temp2=NULL;
	printf("\n\n******************* PRINTING USER DETAILS *********************\n\n");
	temp=head;
	while(temp!=NULL)
	{
		flag=0;
		printf("\nUser RFID:%-12sUser Name:%-12sNo of books taken:%hd\n",temp->uid,temp->uname,temp->cnt);
		temp2=temp->ubook;
		int k=1;
		for(int i=0;i<temp->cnt;i++)
		{
			flag=1;
			if(k==1)
			{
				printf("\nBook RFID\tBook Name\t     Time&Date\n");
				printf("---------------------------------------------------------\n");
				k=0;
			}
			s=remv(ctime(&temp->ubook->t));
			//printf("Book RFID:%s / Book Name:%s / Time:%s   ",temp->ubook->tid,temp->ubook->tname,s);
			printf("%-16s%-16s%s\n",temp2->tid,temp2->tname,s);
			temp2=temp2->link;
		}
		//if(flag==0)
			//printf("This user does not take books\n");
		temp=temp->link;
	}
	printf("\n\n******************* PRINTING BOOK DETAILS *********************\n\n");
        temp1=head1;
	printf("\nBook RFID\tBook Name\tstatus\n");
	printf("---------------------------------------\n");
        while(temp1!=NULL)
        {
                //printf("\nBook RFID:%s\tBook Name:%s\tstatus:%c\n",temp1->bid,temp1->bname,temp1->b_stat);
                printf("%-16s%-16s%c\n",temp1->bid,temp1->bname,temp1->b_stat);
                temp1=temp1->link;
        }
	printf("\n");
}

