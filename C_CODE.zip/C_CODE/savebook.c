#include "header.h"

void savebook(STORE *head1)
{
	STORE *temp=NULL;
	FILE *fp=NULL;
	temp=head1;
	fp=fopen("books.csv","w");
	if(fp==NULL)
	{
		printf(RED"File not created"COLROFF);
		exit(0);
	}
	while(temp)
	{
		fprintf(fp,"%s,%s,%c\n",temp->bid,temp->bname,temp->b_stat);
		temp=temp->link;
	}
	fclose(fp);
}

