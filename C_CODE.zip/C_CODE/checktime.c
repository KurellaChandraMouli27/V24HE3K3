#include<stdio.h>
char *time1();
int main()
{
	char *str;
	str=time1();
	puts(str);
}
