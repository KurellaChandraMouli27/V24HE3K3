#include "header.h"

#define UART_INT_ENABLE 1

extern char arr[10],dummy1;
extern unsigned char j,c,r_flag1;
char w=0,tr[10];

void UART1_isr(void) __irq
{
	if(r_flag1==1)
	{
		arr[9]=U1RBR;
		VICVectAddr = 0;
		return;
	}
  if((U1IIR & 0x04)) //check if receive interrupt
  {
		c = U1RBR;	 		/* Read to Clear Receive Interrupt */
		if(c==0x02)
			j=0;
		else if(c != 0x0d && c!=0x03)
			arr[j++] = c;
		else
		{
			arr[j] = '\0';
			j=0;
			r_flag1 = 1;
		}
  }
  else
  {
      dummy1=U1IIR; //Read to Clear transmit interrupt
  
  }
  VICVectAddr = 0; /* dummy write */
}

void InitUART1 (void) /* Initialize Serial Interface       */ 
{  
  cfgportpin(0,TXD1,PIN_FUNC2);
	cfgportpin(0,RXD1,PIN_FUNC2);          		
  //PINSEL0 = 0x00050000; /* Enable RxD0 and TxD0              */
  U1LCR = 0x83;	/* 8 bits, no Parity, 1 Stop bit     */
  U1DLM = ((DIVISORVAL>>8)&0xFF);
	U1DLL = (DIVISORVAL&0xFF);           /* 9600 Baud Rate @ CCLK/4 VPB Clock  */
  U1LCR = 0x03;         /* DLAB = 0  */
  
  #if UART_INT_ENABLE > 0

  VICIntSelect = 0x00000000; // IRQ
	//VICIntSelect |= 1 << 7; // IRQ
  VICVectAddr0 = (unsigned)UART1_isr;
  VICVectCntl0 = 0x20 | 7; /* UART0 Interrupt */
  VICIntEnable |= 1 << 7;   /* Enable UART0 Interrupt */
 
  U1IIR = 0xc0;
 // U0FCR = 0xc7;
  U1IER = 0x03;       /* Enable UART0 RX and THRE Interrupts */   
             
  #endif
						
}

void UART1_Tx(char ch)  /* Write character to Serial Port    */  
{ 
  while (!(U1LSR & 0x20));
  U1THR = ch;                
}

char UART1_Rx(void)    /* Read character from Serial Port   */
{                     
  while (!(U1LSR & 0x01));
  return (U1RBR);
}

void UART1_Str(char *s)
{
   while(*s)
       UART1_Tx(*s++);
}
/*
void UART1_Rstr(void)
{
	char h;
	int t=0;
	h=UART1_Rx();
	while(h!='\n' || h!='\0')
	{
		tr[t++]=h;
	}
	tr[t]='\0';
	w=1;
}
		
*/
/*
void UART1_Int(unsigned int n)
{
  unsigned char a[10]={0,0,0,0,0,0,0,0,0,0};
  int i=0;
  if(n==0)
  {
    UART1_Tx('0');
	return;
  }
  else
  {
     while(n>0)
	 {
	   a[i++]=(n%10)+48;
	   n=n/10;
	 }
	 --i;
	 for(;i>=0;i--)
	 {
	   UART1_Tx(a[i]);
	 }
   }
}

void UART1_Float(float f)
{
  int x;
  float temp;
  x=f;
  UART1_Int(x);
  UART1_Tx('.');
  temp=(f-x)*100;
  x=temp;
  UART1_Int(x);
}
*/
