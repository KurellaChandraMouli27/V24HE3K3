#include "header.h"
char arr[20],dummy1;
char buff[20],dummy;
unsigned char i,ch,r_flag;
unsigned char j,c,r_flag1;
int exint=0;

void password(s8 *pass)
{
	u8 v,k=0;
	SetCursor(2,0);
  a:v=KeyScan();
	while(ColScan()==0);
	while(v!='A')  //enter
	{
		if(v=='D'  && k!=0)	//backspace
		{
			CmdLCD(SHIFT_DSP_LEFT);
			CharLCD(' ');
			CmdLCD(SHIFT_DSP_LEFT);
			k--;
		}
		else if(v!='D')
		{
			CharLCD(v);
			delay_ms(500);
			CmdLCD(SHIFT_DSP_LEFT);
			CharLCD('*');
			pass[k++]=v;
			if(k>7)
				return;
		}
		v=KeyScan();
		while(ColScan()==0);
	}
	if(k==0)
		goto a;
	pass[k]='\0';
}


int main()
{
	//s8 ptr[]="12345";
	InitUART1();
	InitUART0();
	Init_SPI0();
	InitLCD();
	Init_KPM();
	Enable_EINT1();
	
//	PageWrite_25LC512(0,"12345");
//	PageWrite_25LC512(0,ptr);
	while(1)
	{
		exint=0;
		SetCursor(1,0);
		StrLCD("LIBRARY MANAGING");
		SetCursor(2,4);
		StrLCD("SYSTEM");
		CmdLCD(DSP_ON_CUR_OFF);
		r_flag=0;
		while(r_flag==0);
		if(ch=='R')
		{
			CmdLCD(CLEAR_LCD);
			SetCursor(1,0);
			StrLCD("WAITING FOR CARD");
			SetCursor(2,4);
			StrLCD("SCANING");
			j=0;r_flag1=0;
			while(r_flag1 == 0);
			exint=1;
			CmdLCD(CLEAR_LCD);
			StrLCD("CARD SCANED");
			UART0_Str(arr);
			SetCursor(2,0);
			StrLCD(arr);
			r_flag=0;
			while(r_flag==0);
			if(ch=='L')
			{
				librarian();
				r_flag=0;
				while(r_flag==0);
			}
			else if(ch=='U')
			{
				user();
			}
			else
			{
				CmdLCD(CLEAR_LCD);
				StrLCD("INVALID CARD");
				delay_s(1);
			}
			CmdLCD(CLEAR_LCD);
		}
	}
}	



