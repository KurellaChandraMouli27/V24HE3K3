#include<LPC21xx.h>
#include "uart.h"
#include "delayh.h"

char buff[6]="hello",dummy;
unsigned char i=0,ch,r_flag;
char arr[20],dummy1;
unsigned char j,c,r_flag1;
int main()
{
  InitUART0();
	InitUART1();
   
  while(1)
  {
		i=0;r_flag=0;
		while(r_flag == 0);
		UART0_Str(buff);
		UART1_Str(buff);
		UART0_Str("\n\r");
		UART0_Float(245.21);
		UART0_Str("\n\r");
		delay_s(1);
  }
}
