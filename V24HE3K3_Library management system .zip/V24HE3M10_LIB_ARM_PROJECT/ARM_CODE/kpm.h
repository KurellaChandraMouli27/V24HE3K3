#include "types.h"

u32 ColScan(void);
u32 RowCheck(void);
u32 ColCheck(void);
void Init_KPM(void);
u32 KeyScan(void);

