#include "header.h"

extern char arr[20],dummy1;
extern char buff[20],dummy;
extern unsigned char i,ch,r_flag;
extern unsigned char j,c,r_flag1;

void librarian(void)
{
	s8 pass[10],str[10];
	int flag=0;
	int z=3;
	while(z)
	{
		CmdLCD(CLEAR_LCD);
		SetCursor(1,0);
		StrLCD("ENTER PASSWORD");
		SetCursor(2,0);
		password(pass);
		PageRead_25LC512(0,str);
		CmdLCD(CLEAR_LCD);
		if(strcmp(pass,str)==0)
		{
			StrLCD("CORRECT PWD");
			delay_ms(500);
			flag=1;
			break;
		}
		else
		{
			StrLCD("INVALID PWD");
			delay_ms(500);
		}
		z--;
	}
	if(flag==1)
	{
		UART0_Tx('T');
		CmdLCD(CLEAR_LCD);
		SetCursor(1,0);
		StrLCD("LIBRARY MENU");
	}
	else
		UART0_Tx('F');
}
