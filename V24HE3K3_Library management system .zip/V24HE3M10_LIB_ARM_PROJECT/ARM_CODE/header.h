#ifndef __HEADER_H__
#define __HEADER_H__
#endif

#include <LPC21xx.h>	 
#include <string.h>
#include "types.h"
#include "pin_cfg.h"
#include "delay.h"
#include "uart.h"
#include "spi.h"
#include "spi_eeprom.h"
#include "lcd.h"
#include "kpm.h"
#include "ext_int.h"
#include "defines.h"
#include "spi_eeprom_defines.h"
#include "pin_cfg_defines.h"
#include "lcd_defines.h"
#include "spi_defines.h"
#include "uart_defines.h"
void password(s8 *pass);
void librarian(void);
void user(void);

void Exit(void);
void disstat(void);
void editbook(void);
void delbook(void);
void addbook(void);
void edituser(void);
void deluser(void);
void adduser(void);
