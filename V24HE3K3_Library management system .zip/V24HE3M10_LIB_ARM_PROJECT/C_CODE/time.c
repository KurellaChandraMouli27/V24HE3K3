#include<stdio.h>
#include<time.h>
#include<string.h>

char *remv(char *p)
{
	p[strlen(p)-1]='\0';
	return p;
}

int main()
{
	char *s;
	time_t t;
	time(&t);
	printf("%s",ctime(&t));
	printf("%ld\n",strlen(ctime(&t)));
	s=remv(ctime(&t));
	printf("%s",s);
        printf("%ld\n",strlen(s));
}
