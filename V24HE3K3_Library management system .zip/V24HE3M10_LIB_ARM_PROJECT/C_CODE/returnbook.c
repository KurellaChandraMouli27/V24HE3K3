#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void returnbook(USER *temp)
{
	int flag=0;
	char str[20];
	STORE *temp1=NULL;
	BOOK *temp2=NULL,*prev=NULL;
	if(temp->cnt>0)
	{
		tx='2';
		sleep(1);
		write(fd,&tx,1);
		#ifdef SERIALPORT
			printf(RED"\nEnter the book id to return:\n"COLROFF);
			__fpurge(stdin);
			scanf("%[^\n]s",ptr);
		#else
			printf(YELLOW"\nWaiting for the return book card scan\n"COLROFF);
			serialGetstr(fd,ptr);
		#endif
		if(strlen(ptr)!=8)
       		{
			tx='F';
			sleep(1);
			write(fd,&tx,1);
			printf(RED"\nINVALID CARD\n"COLROFF);
               		return;
        	}
		else
		{
			temp1=head1;
			while(temp1!=NULL)
			{
				if(strcmp(temp1->bid,ptr)==0)
				{
					break;
				}
				temp1=temp1->link;
			}
			temp2=temp->ubook;
			while(temp2!=NULL)
			{
				if(strcmp(temp2->tid,ptr)==0)
				{
					flag=1;
					if(temp2==temp->ubook)
					{
						temp->ubook=temp2->link;
						free(temp2);
					}
					else
					{
						prev->link=temp2->link;
						free(temp2);
					}
					temp1->b_stat='Y';
					temp->cnt--;
					tx='T';
					sleep(1);
					write(fd,&tx,1);
					printf(GREEN"\nBook returned successfully\n"COLROFF);
					break;
				}
				prev=temp2;
				temp2=temp2->link;
			}
			if(flag==0)
			{
				tx='F';
				sleep(1);
                                write(fd,&tx,1);
                                printf(RED"\nThis card not match with existing cards\n"COLROFF);
                                return;
			}
		}
	}
	else
	{
                printf(BLUE"\nNo book on this User\n"COLROFF);
		return;
	}
}
