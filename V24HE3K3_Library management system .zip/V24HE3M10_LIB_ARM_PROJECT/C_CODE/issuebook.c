#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void issuebook(USER *temp)
{
	int flag=0;
	char str[20];
	STORE *temp1=NULL;
	BOOK *temp2=NULL,*newnode=NULL;
	if(temp->cnt<3)
	{
		tx='1';
		sleep(1);
		write(fd,&tx,1);
		#ifdef SERIALPORT
			printf(RED"\nEnter the book id for issuing:\n"COLROFF);
			__fpurge(stdin);
			scanf("%[^\n]s",ptr);
		#else
			printf(YELLOW"\nWaiting for the book card scan\n"COLROFF);
			serialGetstr(fd,ptr);
		#endif
		if(strlen(ptr)!=8)
		{
			tx='F';//failed
			sleep(1);
			write(fd,&tx,1);
			printf(RED"\nINVALID CARD\n"COLROFF);
			return;
       		}
		else
		{
			temp1=head1;
			while(temp1!=NULL)
			{
				if(strcmp(temp1->bid,ptr)==0)
				{
					flag=1;
					if(temp1->b_stat=='Y')
					{
						newnode=calloc(1,sizeof(BOOK));
						strcpy(newnode->tid,ptr);
						strcpy(newnode->tname,temp1->bname);
						temp1->b_stat='N';
						time(&newnode->t);
						if(temp->ubook==NULL)
						{
							temp->ubook=newnode;
						}
						else
						{
							newnode->link=temp->ubook;
							temp->ubook=newnode;
						}
						temp->cnt++;
						printf(GREEN"\nBook issued successfully\n"COLROFF);
						tx='T';
						sleep(1);
                                                write(fd,&tx,1);
						return;
					}
					else
					{
						printf(RED"\nBook assigned to another one\n"COLROFF);
						tx='F';
						sleep(1);
                               			write(fd,&tx,1);
						return;
					}
				}
				temp1=temp1->link;
			}
		}
		if(flag==0)
		{
			tx='F';
			sleep(1);
                        write(fd,&tx,1);
                        printf(RED"\nINVALID CARD\n"COLROFF);
			return;
		}
	}
	else
	{
		printf(RED"\nUSER reached max limit of books\n"COLROFF);
		return;
	}
}




	
