#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void adduser(void)
{
	USER *temp=NULL,*newnode=NULL;
	STORE *temp1=NULL;
	printf("\nEnter the new user card number:");
	__fpurge(stdin);
	ptr[0]='\0';
	scanf("%[^\n]s",ptr);

	if(strlen(ptr)!=8)
	{
		printf(RED"\nINVALID CARD\n"COLROFF);
		return;
	}
	//extra test case
	 temp1=head1;
        while(temp1!=NULL)
        {
                if(strcmp(ptr,temp1->bid)==0)
                {
                        printf(RED"\n***** This is book card can't assign to as user id *****\n"COLROFF);
                        return;
                }
                if(strcmp(ptr,lib_card)==0)
                {
                        printf(RED"\n***** This is librarian card,can't assign to as user id *****\n"COLROFF);
                        return;
                }
                temp1=temp1->link;
        }
	for(int i=0;ptr[i];i++)
	{
		if(ptr[i]>=48 && ptr[i]<=57)
		{
			continue;
		}
		else
		{
			printf(RED"\nINVALID CARD"COLROFF);
			return;
		}
	}
	temp=head;
	while(temp!=NULL)
	{
		if(strcmp(ptr,temp->uid)==0)
		{
			printf(BLUE"\n <<< User already exists :( >>>\n"COLROFF);
			return;
		}
		temp=temp->link;
	}
	newnode=calloc(1,sizeof(USER));
	if(newnode==NULL)
		printf("\nNode not created\n");
	else
	{
		char s[20];	
		strcpy(newnode->uid,ptr);
	      a:printf("\nEnter the new user name:");
		int ch=0;
		s[0]='\0';
		__fpurge(stdin);
		do
		{
			s[ch]=getchar();
		}while((s[ch++]!=10) && ch<20);
		s[ch-1]=0;

		if(ch>=20)
		{
			printf(RED"\nInvalid User Name\n"COLROFF);
			puts(YELLOW"you enter beyond the size \n plese enter the less thar 20 char "COLROFF);
                        goto a;
		}
		if(s[0]!='\0')
		{
			strcpy(newnode->uname,s);
		}
		else
		{
			printf(RED"\nInvalid User Name\n"COLROFF);
			goto a;
		}
		newnode->link=head;
		head=newnode;
	}
	printf(BLUE"\n<<< New user created successfully :) >>>\n"COLROFF);
}

