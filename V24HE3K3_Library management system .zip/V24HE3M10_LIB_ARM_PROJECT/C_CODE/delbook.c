#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void delbook(void)
{
	STORE *temp=NULL,*prev=NULL;
	printf("\nEnter the deleting book card number:");
	__fpurge(stdin);
	ptr[0]='\0';
	scanf("%[^\n]s",ptr);
	if(strlen(ptr)!=8)
	{
		printf("\nInvalid card\n");
		return;
	}
	for(int i=0;ptr[i];i++)
        {
                if(ptr[i]>=48 && ptr[i]<=57)
                {
                        continue;
                }
                else
                {
                        printf(RED"\nINVALID CARD\n"COLROFF);
                        return;
                }
        }

	temp=head1;
	while(temp!=NULL)
	{
		 if(strcmp(ptr,lib_card)==0)
                {
                        printf(YELLOW"\n***** This is librarian card,deleting book is not allowed *****\n"COLROFF);
                        return;
                }


		if(strcmp(ptr,temp->bid)==0)
		{

			if(temp->b_stat=='N')
			{
		printf(YELLOW"\nThis book is assigned to some user,for deleting first return the book"COLROFF);
				return;
			}
			if(temp==head1)
			{
				head1=temp->link;
				free(temp);
			}
			else
			{
				prev->link=temp->link;
				free(temp);
			}
			printf(BLUE"\nBook deleted successfully\n"COLROFF);
			return;
		}
		prev=temp;
		temp=temp->link;
	}
	printf(RED"\nNo book with that card\n"COLROFF);
}

