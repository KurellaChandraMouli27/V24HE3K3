#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void editbook(void)
{
	STORE *temp=NULL,*prev=NULL;
	printf("\nEnter the editing book card number:");
	__fpurge(stdin);
	ptr[0]='\0';
	scanf("%[^\n]s",ptr);
	if(strlen(ptr)!=8)
	{
		printf(RED"\nInvalid card\n"COLROFF);
		return;
	}
	for(int i=0;ptr[i];i++)
        {
                if(ptr[i]>=48 && ptr[i]<=57)
                {
                        continue;
                }
                else
                {
                        printf(RED"\nINVALID CARD\n"COLROFF);
                        return;
                }
        }
	temp=head1;
	while(temp!=NULL)
	{
  //Extra test case
            if(strcmp(ptr,lib_card)==0)
                {
                        printf(YELLOW"\n***** This is librarian card,Editing book name is not performed *****\n"COLROFF);
                        return;
                }


		if(strcmp(ptr,temp->bid)==0)
		{
			char s[10];
			a:printf("\nEnter the new name to book edit:");
			s[0]='\0';
			__fpurge(stdin);
			scanf("%[^\n]s",s);
			if(strlen(s)>=19)
			{
				printf(RED"\nInvalid Book Name\n"COLROFF);
		puts(YELLOW"you Entered beyond the size\n please enter less than 20 characters"COLROFF);
		goto a;
			}
			if(s[0]!='\0')
			{
				strcpy(temp->bname,s);
				printf(BLUE"\nBook details edited successfully\n"COLROFF);
				return;
			}
			else
			{
				printf(BLUE"\nName not edited\n"COLROFF);
				return;
			}
			return;
		}
		prev=temp;
		temp=temp->link;
	}
	printf(RED"\nNo book with that card\n"COLROFF);
}

