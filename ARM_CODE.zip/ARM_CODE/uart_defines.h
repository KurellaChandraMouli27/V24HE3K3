#define FOSC           12000000
#define CCLK           (FOSC*5)
#define PCLK           (CCLK/4)
#define BAUDRATE       9600
#define DIVISORVAL     (PCLK/(BAUDRATE*16))    //391=0x187

#define TXD0            0
#define RXD0            1
#define TXD1            8
#define RXD1            9
