//pin_cfg.h
#include"types.h"
void cfgportpin(u32 portNo,s32 pinNo,u32 pinFunc);
