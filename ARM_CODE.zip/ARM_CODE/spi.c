#include "header.h"


void Init_SPI0(void)
{
	cfgportpin(0,SCK,PIN_FUNC2);    //select pinfunctionality
	cfgportpin(0,MISO,PIN_FUNC2);
	cfgportpin(0,MOSI,PIN_FUNC2);
	//cfgportpin(0,CS,PIN_FUNC2);
	S0SPCCR =8;                    //bit clock rate
	S0SPCR = (MSTR|Mode_3);      //master made CPOL=1 CPHA=1
	IOSET0 |= CS;
	IODIR0 |= CS;
}

u8 SPI0(u8 data)
{
	//u8 stat;
	//stat=S0SPSR;     //clear SPIF
	S0SPDR=data;       //loop spi tx reg
	while((S0SPSR & SPIF)==0);    //wait for tx completion
	return S0SPDR;     //read data from SPI data reg;
}
	





