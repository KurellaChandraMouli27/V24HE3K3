#ifndef __SPI_H__
#define __SPI_H__

#include "types.h"
void Init_SPI0(void);
u8 SPI0(u8);

#endif
